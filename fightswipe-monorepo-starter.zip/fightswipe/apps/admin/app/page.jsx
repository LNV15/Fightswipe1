
export default function Page() {
  return (
    <div>
      <h1>Fightswipe Admin</h1>
      <p>Minimal Admin placeholder. Set NEXT_PUBLIC_API_BASE and start building.</p>
      <ul>
        <li>Users: list, block/unblock</li>
        <li>Bookings: review, confirm, disputes</li>
        <li>Finance: transactions, payouts</li>
      </ul>
    </div>
  );
}
